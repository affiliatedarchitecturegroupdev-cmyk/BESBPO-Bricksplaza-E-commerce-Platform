# Bricksplaza — Ad Creative Package v1.1

Step 2 of the Merchandising & Ad System Expansion (see `Bricksplaza_Merchandising_Ad_System_Expansion_v1.pdf`,
Section 06, for the full slot architecture this package implements).

## Two creative types, on purpose

This package ships two different formats, deliberately, not inconsistently:

| Type | Slots | Format | Why |
|---|---|---|---|
| **`html`** | 1, 2, 3, 4, 6 | Self-contained HTML/CSS page, real photo loaded by URL | These are the larger, more visual placements (hero, mid-page, in-rail, product cross-sell) where real context/photography genuinely helps sell the range |
| **`image`** | 5, 7, 8 | Flat, self-contained PNG | Search Results, Cart, and Thank You are small, functional, transactional real estate — there's no room for a photo to say anything meaningful at 150px tall, so these use Bricksplaza's own running-bond brick graphic system instead |

### Why the `html` slots aren't flat image files

Every `html` slot loads its background photo by URL rather than embedding the pixel data.
This is a genuine sandbox constraint, not a shortcut: this environment's code-execution
sandbox can reach only an allow-listed set of hosts over the network, and image CDNs
(Unsplash included) are not on that list — attempting to download the photo returns
`403: host_not_allowed`. Web search and page-fetch tools *can* reach the wider internet
(that's how the real, correctly-licensed photos below were found and verified), but the
sandbox that builds files cannot pull their binary content in separately.

This isn't purely a workaround, either: all 8 slots run on Bricksplaza's own platform
(homepage, search, product, cart, checkout) as CMS-managed banner components, not exported
creative for a third-party ad network — a real banner in this position is normally built as
HTML/CSS anyway, for the same reasons (responsive, live click-through, editable from the
Business Desk without re-exporting an image every time copy changes).

To preview an `html` ad exactly as designed, open the file in a normal internet-connected
browser — each is sized to its exact pixel dimensions. The `image` ads are ready to use
as-is; no preview step needed.

## Contents

### /ads — the 8 creatives

| File | Slot | Type | Size | Campaign |
|---|---|---|---|---|
| `ad-01-hero-banner.html` | 1. Homepage Hero | html | 1600x400 | Brand awareness — "Every Brick, Every Build." |
| `ad-02-midpage-banner.html` | 2. Homepage Mid-Page | html | 1600x300 | Strategic Partners programme awareness |
| `ad-03-inrail-paving.html` | 3. In-Rail Native (A) | html | 1200x250 | Paving season — 16 profiles, 14 colourways |
| `ad-04-inrail-trade.html` | 4. In-Rail Native (B) | html | 1200x250 | Trade account acquisition |
| `ad-05-search-banner.png` | 5. Search Results | **image** | 1200x150 | Bulk quote request prompt |
| `ad-06-product-crosssell.html` | 6. Product Cross-Sell | html | 800x200 | Jointing sand & sealer bundle |
| `ad-07-cart-banner.png` | 7. Cart Banner | **image** | 700x150 | Sundries upsell |
| `ad-08-thankyou-banner.png` | 8. Thank You Banner | **image** | 700x150 | Referral programme |

### /code — integration scaffolding

- **`ad_slots_manifest.json`** — the data structure behind all 8 slots, including a
  `creativeType` field (`"html"` or `"image"`) so the rendering component knows which
  path to take. This is the shape the Business Desk's Promotion/Banner Manager
  (E-Commerce Spec Section 16) reads and writes when a merchandiser schedules a campaign.
- **`AdBanner.jsx`** — a React component for the Next.js storefront (`apps/web`, per Spec
  Section 19) that renders any slot from the manifest, branching on `creativeType` between
  a plain `<img>` (image slots) and the photo + markup overlay (html slots), respects
  `activeFrom`/`activeTo` scheduling windows, and exposes `onImpression`/`onClick` hooks for
  the analytics integration named in the spec (PostHog/Plausible).
- **`ad-styles.css`** — shared styling for every slot, kept separate from component logic
  so a brand refresh never requires touching `AdBanner.jsx`.
- **`generate_ads.py`** — the generator for the 5 `html` creatives (template-based, easy to
  re-run with new copy/images/sizes).
- **`generate_graphic_ads.py`** — the generator for the 3 `image` creatives, built on the
  same running-bond brick-pattern technique used for the Bricksplaza logo. Text sizing is
  measured against the actual rendered glyph width (not guessed), so re-running with new
  copy will always fit correctly rather than overflow or collide with the wordmark.

## Image Attribution (html slots only)

All photography is real, sourced from Unsplash under the Unsplash License (free for
commercial use). No image was AI-generated. The 3 `image` slots use no external
photography at all — their graphics are entirely Bricksplaza's own brand artwork.

| Photo | Used in |
|---|---|
| Red brick wall | Slot 1 (Hero) |
| Stacked concrete bricks at a construction site, by Divaris Shirichena | Slot 2 (Mid-Page) |
| Two-tone brick paving stones, by Tsuyoshi Kozu | Slot 3 (Paving) |
| Cobblestone street, by Aleksei Tertychnyi | Slot 4 (Trade) |
| Patio with paving slabs, by Tile Merchant Ireland | Slot 6 (Cross-Sell) |

## Next Steps

- Step 3: Update the Bricksplaza corporate website to reflect the expanded merchandising/ad capability
- Step 4: DFI/bank investment package for the Strategic Partners divisions and the Midrand & Cato Ridge yards
