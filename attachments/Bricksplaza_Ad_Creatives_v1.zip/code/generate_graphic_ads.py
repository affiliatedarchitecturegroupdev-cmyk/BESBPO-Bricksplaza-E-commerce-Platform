import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.font_manager import FontProperties
import random

OUT = "/home/claude/bricksplaza-ads/ads-graphics"

FIRED_CLAY = "#A8412E"
FIRED_CLAY_LIGHT = "#C1613E"
CHARCOAL = "#1C1815"
CHARCOAL_2 = "#26211E"
BISQUE = "#EDE1D3"
SLATE = "#5B5651"
EMBER = "#D9A441"

def text_width_data(fig, ax, s, fontsize, fontproperties, renderer):
    """Render text off-screen, measure its actual pixel width, return width in data units."""
    t = ax.text(0, 0, s, fontsize=fontsize, fontproperties=fontproperties, alpha=0)
    fig.canvas.draw()
    bbox = t.get_window_extent(renderer=renderer)
    (x0, y0) = ax.transData.inverted().transform((bbox.x0, bbox.y0))
    (x1, y1) = ax.transData.inverted().transform((bbox.x1, bbox.y1))
    t.remove()
    return abs(x1 - x0), abs(y1 - y0)

def fit_font_size(fig, ax, s, max_width, start_size, fontproperties, renderer, min_size=10):
    size = start_size
    while size > min_size:
        w, h = text_width_data(fig, ax, s, size, fontproperties, renderer)
        if w <= max_width:
            return size, w, h
        size -= 1
    w, h = text_width_data(fig, ax, s, min_size, fontproperties, renderer)
    return min_size, w, h

def build_graphic_ad(fname, w_px, h_px, headline, cta_text, brick_colours,
                      bg_color, accent_color, dpi=200, headline_start_size=26, cta_size=13,
                      brick_w=2.6, brick_h=1.15, pad_left_frac=0.045):
    fig_w, fig_h = w_px / dpi, h_px / dpi
    fig = plt.figure(figsize=(fig_w, fig_h), dpi=dpi)
    ax = fig.add_axes([0, 0, 1, 1])  # no margins at all
    W = w_px / dpi * 96
    H = h_px / dpi * 96
    ax.set_xlim(0, W)
    ax.set_ylim(0, H)
    ax.invert_yaxis()
    ax.set_aspect("equal")
    ax.axis("off")

    renderer = fig.canvas.get_renderer()

    # base background
    ax.add_patch(mpatches.Rectangle((0, 0), W, H, facecolor=bg_color, edgecolor="none", zorder=0))
    # running-bond brick texture panel (right-hand two-thirds)
    panel_x = W * 0.40
    clip_rect = mpatches.Rectangle((panel_x, 0), W - panel_x, H, transform=ax.transData)
    rng_seed = abs(hash(fname)) % 1000
    rows = int(H / brick_h) + 2
    rnd = random.Random(rng_seed)
    for r in range(rows):
        y = r * brick_h
        offset = 0 if r % 2 == 0 else brick_w / 2
        x = panel_x - brick_w + offset
        while x < W + brick_w:
            c = rnd.choice(brick_colours)
            rect = mpatches.Rectangle((x + 0.5, y + 0.5), brick_w - 1.0, brick_h - 1.0,
                                       facecolor=c, edgecolor="none", zorder=1)
            rect.set_clip_path(clip_rect)
            ax.add_patch(rect)
            x += brick_w
    # soft fade strip for text contrast at the panel's left edge
    for i in range(16):
        alpha = 0.9 - i * 0.06
        if alpha < 0:
            break
        ax.add_patch(mpatches.Rectangle((panel_x - 8 + i * 1.6, 0), 1.8, H,
                     facecolor=bg_color, edgecolor="none", alpha=max(alpha, 0), zorder=2))

    # accent bar (full width, top)
    ax.add_patch(mpatches.Rectangle((0, 0), W, H * 0.05, facecolor=accent_color, edgecolor="none", zorder=3))

    fp_bold = FontProperties(family="DejaVu Sans", weight="bold")
    text_x = W * pad_left_frac
    max_headline_w = panel_x - text_x - (W * 0.02)

    size, hw, hh = fit_font_size(fig, ax, headline, max_headline_w, headline_start_size, fp_bold, renderer)
    ax.text(text_x, H * 0.38, headline, fontproperties=fp_bold, fontsize=size,
            color=BISQUE, ha="left", va="center", zorder=4)

    # CTA pill — measured, not guessed
    cta_label = cta_text + "   \u2192"
    cw, ch = text_width_data(fig, ax, cta_label, cta_size, fp_bold, renderer)
    pad_x, pad_y = W * 0.018, H * 0.09
    pill_w, pill_h = cw + pad_x * 2, ch + pad_y * 2
    pill_y = H * 0.66
    ax.add_patch(mpatches.FancyBboxPatch((text_x, pill_y), pill_w, pill_h,
                 boxstyle=f"round,pad=0,rounding_size={pill_h*0.18}",
                 facecolor=FIRED_CLAY, edgecolor="none", zorder=4))
    ax.text(text_x + pill_w/2, pill_y + pill_h/2, cta_label, fontproperties=fp_bold,
            fontsize=cta_size, color="white", ha="center", va="center", zorder=5)

    # wordmark, bottom-right
    ax.text(W - W*0.015, H - H*0.06, "BRICKSPLAZA", fontproperties=fp_bold, fontsize=cta_size * 0.6,
            color=BISQUE, ha="right", va="bottom", alpha=0.85, zorder=5)

    fig.savefig(f"{OUT}/{fname}", dpi=dpi)
    plt.close(fig)
    print(f"wrote {fname}  (headline fit at size {size})")

# Slot 5 — Search Results Banner (1200x150)
build_graphic_ad(
    "ad-05-search-banner.png", 1200, 150,
    "Can't find what you need?", "Request a Bulk Quote",
    brick_colours=[CHARCOAL_2, "#332B26", "#3a322c"],
    bg_color=CHARCOAL, accent_color=EMBER, headline_start_size=26, cta_size=13,
)

# Slot 7 — Cart Banner (700x150)
build_graphic_ad(
    "ad-07-cart-banner.png", 700, 150,
    "Forgot the sundries?", "Shop Sundries",
    brick_colours=[FIRED_CLAY, "#9c3a2a", FIRED_CLAY_LIGHT],
    bg_color=CHARCOAL, accent_color=EMBER, headline_start_size=22, cta_size=11, pad_left_frac=0.05,
)

# Slot 8 — Thank You Banner (700x150)
build_graphic_ad(
    "ad-08-thankyou-banner.png", 700, 150,
    "Loved your order?", "Refer & Earn R500",
    brick_colours=[EMBER, "#cc9938", "#e0ae4e"],
    bg_color=CHARCOAL, accent_color=FIRED_CLAY, headline_start_size=22, cta_size=11, pad_left_frac=0.05,
)

print("\nAll 3 graphic ads rebuilt.")
