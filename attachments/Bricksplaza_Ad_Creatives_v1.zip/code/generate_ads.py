import base64, json, os

OUT = "/home/claude/bricksplaza-ads/ads"
os.makedirs(OUT, exist_ok=True)

with open("/home/claude/bricksplaza-ads/code/icon_primary.png", "rb") as f:
    LOGO_B64 = base64.b64encode(f.read()).decode("ascii")

FIRED_CLAY = "#A8412E"
CHARCOAL = "#26211E"
BISQUE = "#EDE1D3"
SLATE = "#5B5651"
EMBER = "#D9A441"

FONT_LINK = '<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">'

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
{font_link}
<style>
  *{{margin:0;padding:0;box-sizing:border-box;}}
  html,body{{width:{w}px;height:{h}px;overflow:hidden;font-family:'Inter',sans-serif;}}
  .ad{{position:relative;width:{w}px;height:{h}px;background-image:url('{img}');background-size:cover;background-position:center;}}
  .overlay{{position:absolute;inset:0;background:{gradient};}}
  .content{{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:{pad}px;}}
  .eyebrow{{font-family:'Inter',sans-serif;font-weight:700;font-size:{eyebrow_size}px;letter-spacing:2px;text-transform:uppercase;color:{EMBER};margin-bottom:{eyebrow_mb}px;}}
  .headline{{font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:{headline_size}px;line-height:1.1;color:{BISQUE};max-width:{content_w}px;margin-bottom:{headline_mb}px;}}
  .sub{{font-family:'Inter',sans-serif;font-size:{sub_size}px;color:#D9CFC0;max-width:{sub_w}px;margin-bottom:{sub_mb}px;line-height:1.35;}}
  .cta{{display:inline-flex;align-items:center;gap:6px;background:{FIRED_CLAY};color:#fff;font-family:'Inter',sans-serif;font-weight:700;font-size:{cta_size}px;letter-spacing:0.5px;text-transform:uppercase;padding:{cta_pad};border-radius:2px;text-decoration:none;width:fit-content;}}
  .logo{{position:absolute;{logo_pos};display:flex;align-items:center;gap:6px;opacity:0.92;}}
  .logo img{{height:{logo_h}px;}}
  .logo span{{font-family:'Space Grotesk',sans-serif;font-weight:700;font-size:{logo_font}px;color:{BISQUE};}}
</style>
</head>
<body>
<div class="ad">
  <div class="overlay"></div>
  <div class="content">
    {eyebrow_html}
    <div class="headline">{headline}</div>
    {sub_html}
    <a class="cta" href="{cta_link}">{cta_text} \u2192</a>
  </div>
  <div class="logo"><img src="data:image/png;base64,{logo_b64}" alt=""><span>BRICKSPLAZA</span></div>
</div>
</body>
</html>
"""

def build_ad(fname, title, w, h, img, eyebrow, headline, sub, cta_text, cta_link,
             pad, eyebrow_size, headline_size, sub_size, cta_size, content_w, sub_w,
             logo_pos, logo_h, logo_font, gradient, eyebrow_mb=10, headline_mb=12, sub_mb=16,
             cta_pad="10px 20px"):
    eyebrow_html = f'<div class="eyebrow">{eyebrow}</div>' if eyebrow else ""
    sub_html = f'<div class="sub">{sub}</div>' if sub else ""
    html = TEMPLATE.format(
        title=title, w=w, h=h, img=img, gradient=gradient, pad=pad,
        eyebrow_size=eyebrow_size, eyebrow_mb=eyebrow_mb, EMBER=EMBER,
        headline_size=headline_size, BISQUE=BISQUE, content_w=content_w, headline_mb=headline_mb,
        sub_size=sub_size, sub_w=sub_w, sub_mb=sub_mb,
        cta_size=cta_size, FIRED_CLAY=FIRED_CLAY, cta_pad=cta_pad,
        logo_pos=logo_pos, logo_h=logo_h, logo_font=logo_font,
        eyebrow_html=eyebrow_html, headline=headline, sub_html=sub_html,
        cta_text=cta_text, cta_link=cta_link, logo_b64=LOGO_B64, font_link=FONT_LINK,
    )
    with open(f"{OUT}/{fname}", "w") as f:
        f.write(html)
    print("wrote", fname)

DARK_LR = f"linear-gradient(90deg, rgba(28,24,21,0.88) 0%, rgba(28,24,21,0.45) 55%, rgba(28,24,21,0.15) 100%)"
DARK_FULL = f"linear-gradient(180deg, rgba(28,24,21,0.35) 0%, rgba(28,24,21,0.75) 100%)"
DARK_STRONG = f"linear-gradient(90deg, rgba(28,24,21,0.92) 0%, rgba(28,24,21,0.6) 60%, rgba(28,24,21,0.25) 100%)"

# ---------------------------------------------------------------
# SLOT 1 — Homepage Hero Banner (1600x400)
# ---------------------------------------------------------------
build_ad(
    "ad-01-hero-banner.html", "Ad Slot 1 — Homepage Hero Banner", 1600, 400,
    "https://images.unsplash.com/photo-1479670612349-3b5dba5179c7?auto=format&fit=crop&w=1920&q=80",
    "Bricksplaza", "Every Brick, Every Build.",
    "2,044 SKUs across 21 categories \u2014 South Africa's most comprehensive masonry range.",
    "Explore the Range", "/products",
    pad=60, eyebrow_size=15, headline_size=48, sub_size=18, cta_size=14,
    content_w=820, sub_w=620, logo_pos="bottom:28px; right:36px", logo_h=34, logo_font=17,
    gradient=DARK_LR, cta_pad="14px 28px",
)

# ---------------------------------------------------------------
# SLOT 2 — Homepage Mid-Page Banner (1600x300)
# ---------------------------------------------------------------
build_ad(
    "ad-02-midpage-banner.html", "Ad Slot 2 — Homepage Mid-Page Banner", 1600, 300,
    "https://images.unsplash.com/photo-1787672357563-5cbaf3afc327?auto=format&fit=crop&w=1920&q=80",
    "Strategic Partners Programme", "Supplying Construction Companies, Developers & Hardware Stores",
    "Tiered pricing, dedicated account management, and credit terms built for your business.",
    "See Partner Programmes", "/partners",
    pad=50, eyebrow_size=14, headline_size=32, sub_size=16, cta_size=13,
    content_w=760, sub_w=560, logo_pos="bottom:22px; right:30px", logo_h=28, logo_font=15,
    gradient=DARK_LR, cta_pad="12px 24px",
)

# ---------------------------------------------------------------
# SLOT 3 — In-Rail Native Banner (1200x250) — Paving Season
# ---------------------------------------------------------------
build_ad(
    "ad-03-inrail-paving.html", "Ad Slot 3 — In-Rail Native Banner (Paving)", 1200, 250,
    "https://images.unsplash.com/photo-1759249919714-5cbf77de4d9d?auto=format&fit=crop&w=1600&q=80",
    "Paving Season", "16 Paver Profiles. 14 Colourways.",
    "From pedestrian pathways to extra-heavy-duty industrial yards.",
    "Shop Pavers", "/categories/interlocking-concrete-paver",
    pad=40, eyebrow_size=13, headline_size=26, sub_size=14, cta_size=12,
    content_w=560, sub_w=460, logo_pos="bottom:18px; right:24px", logo_h=22, logo_font=13,
    gradient=DARK_STRONG, cta_pad="10px 20px", headline_mb=8, sub_mb=12,
)

# ---------------------------------------------------------------
# SLOT 4 — In-Rail Native Banner (1200x250) — Trade Accounts
# ---------------------------------------------------------------
build_ad(
    "ad-04-inrail-trade.html", "Ad Slot 4 — In-Rail Native Banner (Trade)", 1200, 250,
    "https://images.unsplash.com/photo-1741943475832-e7cad65ab052?auto=format&fit=crop&w=1600&q=80",
    "Trade Accounts", "Register for Trade Pricing",
    "20% off Retail on every SKU, every order.",
    "Apply Now", "/account/trade-application",
    pad=40, eyebrow_size=13, headline_size=26, sub_size=14, cta_size=12,
    content_w=560, sub_w=460, logo_pos="bottom:18px; right:24px", logo_h=22, logo_font=13,
    gradient=DARK_STRONG, cta_pad="10px 20px", headline_mb=8, sub_mb=12,
)

# ---------------------------------------------------------------
# SLOT 5 — Search Results Banner (1200x150)
# ---------------------------------------------------------------
build_ad(
    "ad-05-search-banner.html", "Ad Slot 5 — Search Results Banner", 1200, 150,
    "https://images.unsplash.com/photo-1617713965103-9fda56c89fad?auto=format&fit=crop&w=1600&q=80",
    "", "Can't find exactly what you're looking for?",
    "", "Request a Bulk Quote", "/support/bulk-quote",
    pad=30, eyebrow_size=0, headline_size=22, sub_size=0, cta_size=12,
    content_w=680, sub_w=0, logo_pos="bottom:14px; right:22px", logo_h=18, logo_font=11,
    gradient=DARK_STRONG, cta_pad="9px 18px", headline_mb=10, eyebrow_mb=0,
)

# ---------------------------------------------------------------
# SLOT 6 — Product Cross-Sell Banner (800x200)
# ---------------------------------------------------------------
build_ad(
    "ad-06-product-crosssell.html", "Ad Slot 6 — Product Cross-Sell Banner", 800, 200,
    "https://images.unsplash.com/photo-1719324923613-ff0884b031ed?auto=format&fit=crop&w=1200&q=80",
    "Complete the Project", "Add Jointing Sand & Sealer",
    "Save 10% when bundled with your paver order.",
    "Add Bundle", "/bundles/paving-finishing-kit",
    pad=32, eyebrow_size=12, headline_size=22, sub_size=13, cta_size=11,
    content_w=440, sub_w=380, logo_pos="bottom:16px; right:20px", logo_h=18, logo_font=11,
    gradient=DARK_STRONG, cta_pad="9px 18px", headline_mb=8, sub_mb=10,
)

# ---------------------------------------------------------------
# SLOT 7 — Cart Banner (700x150)
# ---------------------------------------------------------------
build_ad(
    "ad-07-cart-banner.html", "Ad Slot 7 — Cart Banner", 700, 150,
    "https://images.unsplash.com/photo-1617713965103-9fda56c89fad?auto=format&fit=crop&w=1200&q=80",
    "", "Forgot the sundries?",
    "", "Add Brickforce, Sand & Sealer", "/categories/mortar-jointing-sundries",
    pad=26, eyebrow_size=0, headline_size=19, sub_size=0, cta_size=11,
    content_w=380, sub_w=0, logo_pos="bottom:12px; right:18px", logo_h=16, logo_font=10,
    gradient=DARK_STRONG, cta_pad="8px 16px", headline_mb=8, eyebrow_mb=0,
)

# ---------------------------------------------------------------
# SLOT 8 — Thank You Banner (700x150)
# ---------------------------------------------------------------
build_ad(
    "ad-08-thankyou-banner.html", "Ad Slot 8 — Thank You Banner", 700, 150,
    "https://images.unsplash.com/photo-1761637822930-fb1c1a3df94d?auto=format&fit=crop&w=1200&q=80",
    "", "Loved your order?",
    "", "Refer a Friend, Get R500 Credit", "/account/referral",
    pad=26, eyebrow_size=0, headline_size=19, sub_size=0, cta_size=11,
    content_w=380, sub_w=0, logo_pos="bottom:12px; right:18px", logo_h=16, logo_font=10,
    gradient=DARK_STRONG, cta_pad="8px 16px", headline_mb=8, eyebrow_mb=0,
)

print("\nAll 8 ad creatives written.")
