/**
 * AdBanner.jsx
 *
 * Renders a single ad slot from ad_slots_manifest.json inside the Next.js storefront
 * (apps/web, per the E-Commerce Platform Technical Specification v1.0, Section 3/19).
 *
 * The manifest is the same data shape the Business Desk's Promotion/Banner Manager
 * (Spec Section 16) reads and writes — a merchandiser scheduling a new campaign updates
 * the `campaign` object for a slot; this component only ever reads it.
 *
 * Usage:
 *   import AdBanner from "@/components/AdBanner";
 *   import manifest from "@/data/ad_slots_manifest.json";
 *
 *   <AdBanner slot={manifest.slots.find(s => s.id === "hero-banner")} />
 *
 * Notes:
 * - Two creative types, branched on `slot.creativeType`:
 *     "html"  — real sourced photography loaded live by the browser + markup overlay
 *               (Slots 1, 2, 3, 4, 6 — the larger, more visual placements)
 *     "image" — a self-contained flat PNG using Bricksplaza's own brand graphic system,
 *               no external photo (Slots 5, 7, 8 — small, functional placements where a
 *               photo has no room to say anything at this size)
 * - No inline styles beyond layout sizing — visual design lives in ad-styles.css
 *   (packages/ui/styles/ad-styles.css once merged into the monorepo) so brand updates
 *   don't require touching this component.
 * - `activeFrom` / `activeTo` (ISO date strings, nullable) let the Business Desk schedule
 *   a campaign in advance or let it expire automatically — this component hides the slot
 *   entirely outside that window rather than rendering stale creative.
 * - Click tracking is a single onClick hook, left for the analytics integration named in
 *   the Spec (PostHog/Plausible, Section 3) to wire up — not hard-coded to a vendor here.
 */

import { useMemo } from "react";

function isWithinActiveWindow(campaign) {
  const now = new Date();
  if (campaign.activeFrom && new Date(campaign.activeFrom) > now) return false;
  if (campaign.activeTo && new Date(campaign.activeTo) < now) return false;
  return true;
}

export default function AdBanner({ slot, onImpression, onClick }) {
  const shouldRender = useMemo(() => {
    if (!slot || !slot.campaign) return false;
    return isWithinActiveWindow(slot.campaign);
  }, [slot]);

  if (!shouldRender) return null;

  const { campaign, width, height, name, id, creativeType, creativeFile } = slot;

  const handleClick = () => {
    if (onClick) onClick({ slotId: id, slotName: name, ctaLink: campaign.ctaLink });
  };

  const wrapperProps = {
    className: "ad-banner",
    "data-slot-id": id,
    "data-slot-name": name,
    style: { width: "100%", maxWidth: `${width}px`, aspectRatio: `${width} / ${height}` },
    ref: (el) => {
      // Fire a single impression event the first time this slot mounts in view.
      // A production build would swap this for an IntersectionObserver-gated call.
      if (el && onImpression) onImpression({ slotId: id, slotName: name });
    },
  };

  // creativeType "image": a self-contained flat PNG (Bricksplaza's own brand graphic,
  // no external photo) — used for Search/Cart/Thank You, where a photo has no room to
  // say anything at this size. Just an <img>, wrapped in the same clickable link.
  if (creativeType === "image") {
    return (
      <div {...wrapperProps}>
        <a href={campaign.ctaLink} onClick={handleClick} className="ad-banner__image-link">
          <img
            src={`/ads/${creativeFile}`}
            alt={campaign.headline}
            width={width}
            height={height}
            style={{ width: "100%", height: "100%", display: "block" }}
          />
        </a>
      </div>
    );
  }

  // creativeType "html": real sourced photography loaded live by the browser, with the
  // headline/CTA overlay rendered as markup — used for the larger, more visual slots.
  return (
    <div {...wrapperProps}>
      <a
        href={campaign.ctaLink}
        onClick={handleClick}
        className="ad-banner__link"
        style={{ backgroundImage: `url(${campaign.imageSource}?auto=format&fit=crop&w=${width}&q=80)` }}
      >
        <div className="ad-banner__overlay" />
        <div className="ad-banner__content">
          {campaign.eyebrow && <div className="ad-banner__eyebrow">{campaign.eyebrow}</div>}
          <div className="ad-banner__headline">{campaign.headline}</div>
          {campaign.subtext && <div className="ad-banner__sub">{campaign.subtext}</div>}
          <span className="ad-banner__cta">{campaign.ctaText} \u2192</span>
        </div>
      </a>
    </div>
  );
}
