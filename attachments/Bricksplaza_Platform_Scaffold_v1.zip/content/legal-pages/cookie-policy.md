# Cookie Policy

> STATUS: DRAFT STUB — legal review required before publish (see Spec Section 23, Open Questions).

_This file is a placeholder for Phase 1 scaffolding. Final legal copy must be drafted and reviewed
by a qualified attorney before this page goes live, consistent with the Bricksplaza Compliance &
Regulatory Framework v1.0 and Besbpo Group's standard contract review process._

## Sections to cover
- Scope and applicability
- Definitions
- Customer/company obligations
- Governing law (Republic of South Africa)
- Contact details for queries
