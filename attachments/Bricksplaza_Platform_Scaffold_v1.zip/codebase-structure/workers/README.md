# workers — BullMQ Job Processors (Node)

## Queues (planned)
- `email` — transactional email (order confirmation, password reset, shipping updates)
- `delivery-sync` — polls/receives carrier webhooks (DSV, Faber Vervoer, Panamax) and
  normalises status into the internal Shipment schema (Spec Section 14)
- `search-reindex` — triggers services/search-indexer on catalogue/pricing changes
- `abandoned-cart` — scheduled reminder emails (Spec Section 13)
