# infra — Infrastructure as Code

- `terraform/` — provisions the Postgres (Supabase), Redis (Upstash), and S3-compatible
  storage resources referenced in Spec Section 3
- `render.yaml` — Render service definitions for apps/web, apps/admin, services/api,
  the three Python services, and the BullMQ workers
