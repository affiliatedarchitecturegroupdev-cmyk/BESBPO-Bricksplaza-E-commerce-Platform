# apps/admin — Bricksplaza Business Desk

Separate Next.js app, role-gated staff access only. See Spec Section 17.

## Route groups (planned)
- `(dashboard)` — KPI overview
- `(orders)` — order management, returns/RMA
- `(catalogue)` — product/inventory management, pricing engine console
- `(customers)` — customer + trade account management
- `(reports)` — analytics & reporting

Shares `packages/ui` and `packages/types` with apps/web but ships as an independently
deployed Render service for security isolation (Spec Section 23, Open Questions).
