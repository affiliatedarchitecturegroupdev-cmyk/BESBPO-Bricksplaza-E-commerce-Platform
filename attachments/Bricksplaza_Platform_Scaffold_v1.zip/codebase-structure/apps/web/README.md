# apps/web — Bricksplaza Storefront

Next.js 14 (App Router), TypeScript, React, Tailwind CSS.

## Route groups (planned)
- `(marketing)` — homepage, category landing, blog, static/legal pages
- `(shop)` — category listing, product detail, search results
- `(account)` — sign in/up, dashboard, order history, addresses, wishlist
- `(checkout)` — cart, delivery, payment, review, confirmation

## Key libraries
- Auth.js (NextAuth) for the 6 authentication methods (Spec Section 5)
- Shared components from `packages/ui`
- Shared types from `packages/types`

See Spec Section 19 (File Structure) and Section 8 (Product Detail Pages) for full detail.
