# packages/config — Shared Config

Shared ESLint, TypeScript and Tailwind configuration consumed by every app/service
in the monorepo, so lint/format/type rules never drift between apps/web and apps/admin.
