# packages/types — Shared TypeScript Types

Canonical types for Product, Order, Customer, User, Review, etc. — generated from
(or kept in sync with) the Postgres schema (Spec Section 18, Data Model Overview)
so the frontend and API never disagree on shape.
