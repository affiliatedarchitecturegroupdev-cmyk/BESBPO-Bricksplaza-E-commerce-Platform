# packages/ui — Shared Design System

Shared React components used by both apps/web and apps/admin, styled against
the Kiln palette (see /design/palette.css and /design/palette.json at the repo root
of the scaffold ZIP, or design/ once merged into this monorepo).
