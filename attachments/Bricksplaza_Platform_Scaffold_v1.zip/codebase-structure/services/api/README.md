# services/api — NestJS API Gateway

REST + GraphQL gateway. See Spec Section 3 (Technology Stack) and Section 4 (Architecture).

## Modules (planned)
auth, catalogue, pricing, orders, payments, delivery, reviews, cms

Each module follows standard NestJS structure: `*.module.ts`, `*.controller.ts`,
`*.service.ts`, `dto/`, `entities/`.
