# services/search-indexer — Python/FastAPI

Keeps the Typesense/Meilisearch index in sync with Postgres (Spec Section 9).
Triggered by a BullMQ job on any catalogue or pricing change.

Indexes: product name, category, colour, SKU, applicable standard, plus all
facet fields (category, colour, size, duty class, price, fulfilment type, sectors).
