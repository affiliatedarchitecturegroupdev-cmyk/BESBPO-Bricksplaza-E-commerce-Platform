# services/doc-generator — Python/FastAPI

Generates per-SKU spec-sheet PDFs and order invoices/receipts (Spec Section 8, Section 12).
Uses the same catalogue/pricing data contract as the storefront — never a second source of truth.
