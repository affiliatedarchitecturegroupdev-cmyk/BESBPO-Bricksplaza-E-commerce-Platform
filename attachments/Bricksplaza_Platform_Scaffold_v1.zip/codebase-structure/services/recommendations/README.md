# services/recommendations — Python/FastAPI

Serves three surfaces from one model set (Spec Section 10):
1. Content-based similarity (colour/category/attribute) — powers colour-matched cross-linking
2. Collaborative filtering ("customers who bought this also bought")
3. Merchandiser-curated bundles (read from Postgres, not modelled)

Cold-start note: collaborative filtering activates only once sufficient order volume exists.
