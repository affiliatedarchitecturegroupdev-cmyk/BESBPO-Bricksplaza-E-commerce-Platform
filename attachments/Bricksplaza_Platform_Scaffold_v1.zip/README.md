# Bricksplaza Platform — Scaffold Package v1.0

Companion package to the *Bricksplaza E-Commerce Platform Technical & Product Specification v1.0*
(Section 24, Appendix). This is Phase 1 starter scaffolding, not a working application —
it exists to save the build agents (and the humans reviewing them) time on Day 1.

## Contents

- **/design** — brand logo assets (SVG + PNG, all variants: primary, reversed, mono, app icon,
  both horizontal lockups) plus the Kiln colour palette as both CSS custom properties
  (`palette.css`) and JSON design tokens (`palette.json`)

- **/content** — homepage section configuration (`homepage-sections.json`, all 16 sections),
  the product-page content/data schema (`product-page-schema.md`), and 9 legal-page
  Markdown stubs under `/legal-pages` — every one flagged DRAFT and requiring attorney
  review before publish (see Spec Section 23)

- **/contacts** — `group-contacts.json`, a reference file for the Besbpo Group ecosystem
  footer, contact page, and confirmed contact addresses

- **/codebase-structure** — the monorepo skeleton described in Spec Section 19: folder
  structure with a README per module, root `package.json` and `pnpm-workspace.yaml`,
  a local-dev `docker-compose.yml` (Postgres/Redis/Typesense), a Render `render.yaml`
  service-definition stub, `.env.example` covering every integration named in the spec,
  and `AGENTIC_RULES.md` as the standalone reference the build agents work against

## How to use this

1. Copy `/codebase-structure`'s contents into a new git repository as the monorepo root
2. Copy `/design` into that repo (e.g. as `apps/web/public/brand/` and a shared
   `packages/ui/tokens/`)
3. Point Phase 1 agent tasks at `AGENTIC_RULES.md` and the main specification PDF
4. Treat everything in `/content/legal-pages` as blocked until a human confirms legal
   sign-off — do not launch with draft legal copy live

This package intentionally does not include working application code — per the
specification's own phasing (Section 22), that is Phase 1's deliverable, built by the
agentic process this scaffold sets up for.
